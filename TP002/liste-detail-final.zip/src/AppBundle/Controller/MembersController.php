<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class MembersController extends Controller
{
	
	private $members = [
		'member1-id' => [
			'firstName' => 'First name member1',
			'lastName' => 'Last name member1',
			'email' => 'member1@contact.com',
			'thumbnail' => 'http://lorempixel.com/200/200/people/1',
		],
		'member2-id' => [
			'firstName' => 'First name member2',
			'lastName' => 'Last name member2',
			'email' => 'member2@contact.com',
			'thumbnail' => 'http://lorempixel.com/200/200/people/2',
		],
		'member3-id' => [
			'firstName' => 'First name member3',
			'lastName' => 'Last name member3',
			'email' => 'member3@contact.com',
			'thumbnail' => 'http://lorempixel.com/200/200/people/3',
		],
	];

    /**
     * @Route("/members", name="app.members.index")
     */
    public function indexAction()
    {
        return $this->render('members/index.html.twig', [
            'members' => $this->members
        ]);
    }

	/**
     * @Route("/member/{slug}", name="app.members.detail")
     */
    public function detailAction(string $slug)
    {
		$member = $this->members[$slug];
        return $this->render('members/detail.html.twig', [
			'slug' => $slug,
            'member' => $member
        ]);
    }
}
